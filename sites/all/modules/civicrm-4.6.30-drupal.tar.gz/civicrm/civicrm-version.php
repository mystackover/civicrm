<?php
function civicrmVersion( ) {
  return array( 'version'  => '4.6.30',
                'cms'      => 'Drupal',
                'revision' => '' );
}

